   
        if cmd == "":
            continue
        if err != None  cmd == "cls"  cmd == "clear" or cmd == "c":
            this.conn.write("\033[2J\033[1;1H")
            this.conn.write("\r\x1b[1;37m             \x1b[1;31m       .::.   \r\n")
            this.conn.write("\r\x1b[1;37m             \x1b[1;31m     .:'  .:  \r\n")
            this.conn.write("\r\x1b[1;37m        ,MMM8\x1b[1;31m&&&.:'   .:'  \r\n")
            this.conn.write("\r\x1b[1;37m       MMMMM88\x1b[1;31m&&&&  .:'    \r\n")
            this.conn.write("\r\x1b[1;37m      MMMMM88\x1b[1;31m&&&&&&:'      \r\n")
            this.conn.write("\r\x1b[1;37m      MMMMM88\x1b[1;31m&&&&&&        \r\n")
            this.conn.write("\r\x1b[1;37m    .:MMMMM88\x1b[1;31m&&&&&&        \r\n")
            this.conn.write("\r\x1b[1;37m  .:'  MMMMM88\x1b[1;31m&&&&         \r\n")
            this.conn.write("\r\x1b[1;37m.:'   .:'MMM8\x1b[1;31m&&&'          \r\n")
            this.conn.write("\r\x1b[1;37m:'  .:'      \x1b[1;31m              \r\n")
            this.conn.write("\r\x1b[1;37m'::'         \x1b[1;31m              \r\n")
            this.conn.write("\r\n\033[0m")
            continue
